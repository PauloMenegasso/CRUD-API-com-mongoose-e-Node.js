import express from 'express';
import { studentRouter } from './routes/studentRouter.js';
import mongoose from 'mongoose';

//Conectar ao MongoDB pelo Mongoose
(async () => {
  try {
    //  await mongoose.connect(IMPLEMENTAR AQUI A CONEXÃO COM MEU ATLAS);
    console.log('Conectado com sucesso ao MongoDB');
  } catch (error) {
    console.log('Erro ao conectar ao MongoDB' + error);
  }
})();

const app = express();

app.use(express.json());
app.use(studentRouter);

app.listen(3000, () => console.log('API iniciada'));
